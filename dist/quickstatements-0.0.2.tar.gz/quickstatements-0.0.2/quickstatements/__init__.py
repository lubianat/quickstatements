
"""Top-level package for quickstatements."""

__author__ = """Tiago Lubiana Alves"""
__email__ = 'tiago.lubiana.alves@usp.br'
__version__ = '0.0.2'