# quickstatements

A python module for reconciling datasets to quickstatements / Wikidata format. 

It is still in an inception/pre-prototyping stage. For more info, check the [Wiki](/Wiki).

## Protoype branch

The tracer branch is dedicated to a few prototypes to play around before actually having a workable version of the package. 

The idea is to document on the repository Wiki alongside the development of the prototypes.